# Whatsapp-scripts
Open source spam script made by me, i'm not responsible for any damage made with this tool. This is just a tool, and the good or bad use of it is up to you

## How to use the script:
### Normal version:

- Go to the [Spam script](Spam_script.js) file
- Copy all the code from the file
- Go to [WhatsApp Web](https://web.whatsapp.com)
- Open the console (actions may vary based on the browser, on Chrome you can either use <kbd>F12</kbd> or <kbd>CTRL</kbd>+<kbd>SHIFT</kbd>+<kbd>I</kbd>)
- Paste the code into the console and press <kbd>ENTER</kbd>
- You should see a box appear above your chats
- Enter the chat you want to send messages to
- Type your message in the box 'Message' that you made earlier
- Type the number of times you want to send that message (you can also use arrows to increase/decrease the number)
- Click the send symbol and wait for the messages to be sent (they can take some time)

### Tampermonkey version:

- Go to the [Spam script (Tampermonkey version)](Spam_script_Tampermonkey.js) file
- Copy all the code from the file
- Go into the Tampermonkey menu and click 'Add new script'
- Paste the code into the script, then click on File > Save
- Go to [WhatsApp Web](https://web.whatsapp.com)
- You should see a box above your chats
- Enter the chat you want to send messages to
- Type your message in the box 'Message' that you saw earlier
- Type the number of times you want to send that message (you can also use arrows to increase/decrease the number)
- Click the send symbol and wait for the messages to be sent (they can take some time)

#### Credits:

- [Liad Livnat](https://stackoverflow.com/users/345944/liad-livnat) @ StackOverflow - For providing the core of this script with his event script
- [Rodrigo Manguinho](https://stackoverflow.com/users/1007583/rodrigo-manguinho) @ StackOverlow - For updating that core and making this script to work again
- [eduardomazolini](https://github.com/eduardomazolini) @ GitHub
- CadillacOne for some css ideas
- [thebigsmileXD](https://github.com/thebigsmileXD) @ GitHub
- [EndBug](https://github.com/EndBug) @ GitHub
